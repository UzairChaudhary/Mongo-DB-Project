/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gym_management_system;

import com.mongodb.*;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Aggregates.*;
import com.mongodb.client.model.Filters;
import java.util.Arrays;
import java.util.List;
import org.bson.Document;


/**
 *
 * @author chaud
 */
public class ConnectionClass {
    public static void main(String [] args){
  //  public void connect(){
        try{
    MongoClient mc = new MongoClient("localhost",27017);
    System.out.println("Connection Done");
    MongoDatabase mydb=mc.getDatabase("uzair");
    MongoCollection mycoll = 
    mydb.getCollection("Customer");    
    FindIterable docs = mycoll.find();
    MongoCursor it = docs.iterator();
    
    while(it.hasNext()){
        System.out.println(it.next().toString());
    }
        }
    
    catch(Exception e){
            System.out.println(e.toString());
            }
    
    }
}
        
